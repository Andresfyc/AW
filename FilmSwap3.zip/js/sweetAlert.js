Swal.fire({
    title: "Success!",
    text: "Your order processed successfully.",
    icon: 'success'
});