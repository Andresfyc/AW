IMPLEMENTACIONES:

-Perfil usuario.
-Página con información de Actores y Directores.
-Página con información de Película con Reviews.
-Adaptar foro.
-Adaptar buscar.php.
-Rellenar la base de datos con datos reales.
-Mejorar vista de actores, directores y swappers.
-Arreglar editar película.
-Añadir género en BBDD.
-Filtrar y ordenar en la lista de películas.
-Funcionalidad moderador.
-Crear tabla que maneje automáticamente las películas vistas o valoradas.
-Añadir tablas de plataformas y conectarlas con las peliculas.
-Actualizar logo e icono.
-CSS.
-VPS.