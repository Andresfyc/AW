<header>
    <h1 class="titulo">FilmSwap</h1>

    <div class="navbar">
        <a class="active" href="index.php"><i class="fa fa-fw fa-home"></i> Inicio</a>
        <a href="peliculas.php"><i class="fa fa-film"></i> Peliculas</a>
        <a href="foro.php"><i class="fa fa-commenting"></i> Foro</a>
        <a class="premium" href="premium.php"><i class="fa fa-star" ></i> Premium </a>
        <div class="search-container">
            <form id="buscador" name="buscador" method="post" action="././buscar.php">
                <input id="search" name="search" type="text" placeholder="Buscar..." >
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
    </div>

</header>